require 'test_helper'

class DccHelperTest < ActionView::TestCase
end
