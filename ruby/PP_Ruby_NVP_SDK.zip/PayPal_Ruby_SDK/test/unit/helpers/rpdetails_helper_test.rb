require 'test_helper'

class RpdetailsHelperTest < ActionView::TestCase
end
