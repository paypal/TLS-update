require 'test_helper'

class GtdHelperTest < ActionView::TestCase
end
