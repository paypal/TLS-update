require 'test_helper'

class GetbalanceHelperTest < ActionView::TestCase
end
