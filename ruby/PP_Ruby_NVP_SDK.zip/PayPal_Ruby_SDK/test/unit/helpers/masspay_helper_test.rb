require 'test_helper'

class MasspayHelperTest < ActionView::TestCase
end
