require 'test_helper'

class TsHelperTest < ActionView::TestCase
end
