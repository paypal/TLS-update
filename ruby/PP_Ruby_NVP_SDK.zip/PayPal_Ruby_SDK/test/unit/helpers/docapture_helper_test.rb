require 'test_helper'

class DocaptureHelperTest < ActionView::TestCase
end
