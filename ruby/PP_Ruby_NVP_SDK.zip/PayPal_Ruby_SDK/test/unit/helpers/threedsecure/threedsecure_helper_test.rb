require 'test_helper'

class Threedsecure::ThreedsecureHelperTest < ActionView::TestCase
end
