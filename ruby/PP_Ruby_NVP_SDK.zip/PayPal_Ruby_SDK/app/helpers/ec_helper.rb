module EcHelper
end
