module DovoidHelper
end
