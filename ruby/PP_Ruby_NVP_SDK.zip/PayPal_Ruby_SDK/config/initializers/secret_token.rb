# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
RubySdk::Application.config.secret_token = '013895b520a27f523f3f8fee6e6c8a05e9c0ccc4948e7cf6228995f0d451f83b2a855560c73e25975363ee286f7d82ed4bbb5b4e4de4dbd428b40ad27adbee92'
